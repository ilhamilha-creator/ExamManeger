using Xunit;
using GestionExamens.Services;
using System;

namespace GestionExamens.Tests
{
    public class TestsExportNotificationAdvanced
    {
        [Fact]
        public void ExporterEnPdf_WithInvalidData_ThrowsException()
        {
            var service = new ExportService();
            Assert.Throws<ArgumentNullException>(() => service.ExporterEnPdf(null));
        }

        [Fact]
        public void ExporterEnExcel_WithInvalidData_ThrowsException()
        {
            var service = new ExportService();
            Assert.Throws<ArgumentNullException>(() => service.ExporterEnExcel(null));
        }

        [Fact]
        public void EnvoyerEmail_WithInvalidAddress_ThrowsException()
        {
            var service = new NotificationService();
            Assert.Throws<ArgumentException>(() => service.EnvoyerEmail("invalid-email", "Sujet", "Message"));
        }

        [Fact]
        public void AfficherTableauDeBord_WithNullUser_ThrowsException()
        {
            var service = new NotificationService();
            Assert.Throws<ArgumentNullException>(() => service.AfficherTableauDeBord(null));
        }
    }
}
