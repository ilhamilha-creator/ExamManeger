using Xunit;
using GestionExamens.Controllers;
using Microsoft.AspNetCore.Mvc;
using GestionExamens.ViewModels;

namespace GestionExamens.Tests
{
    public class TestsAuthentification
    {
        [Fact]
        public void Connexion_ValidModel_ReturnsRedirect()
        {
            var controller = new CompteController();

            var vm = new VMConnexion
            {
                Email = "test@example.com",
                MotDePasse = "password"
            };

            var result = controller.Connexion(vm) as RedirectToActionResult;

            Assert.NotNull(result);
            Assert.Equal("Index", result.ActionName);
            Assert.Equal("Home", result.ControllerName);
        }

        [Fact]
        public void Connexion_InvalidModel_ReturnsView()
        {
            var controller = new CompteController();
            controller.ModelState.AddModelError("Email", "Email requis");

            var vm = new VMConnexion();

            var result = controller.Connexion(vm) as ViewResult;

            Assert.NotNull(result);
            Assert.False(controller.ModelState.IsValid);
        }
    }
}
