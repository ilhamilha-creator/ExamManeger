using System.Net;
using System.Threading.Tasks;
using Xunit;
using Microsoft.AspNetCore.Mvc.Testing;

namespace GestionExamens.Tests
{
    public class IntegrationTestsEtudiant : IClassFixture<WebApplicationFactory<GestionExamens.Program>>
    {
        private readonly WebApplicationFactory<GestionExamens.Program> _factory;

        public IntegrationTestsEtudiant(WebApplicationFactory<GestionExamens.Program> factory)
        {
            _factory = factory;
        }

        [Fact]
        public async Task Get_ExamensAVenir_UnauthorizedWithoutLogin()
        {
            var client = _factory.CreateClient();

            var response = await client.GetAsync("/Etudiant/ExamensAVenir");

            Assert.Equal(HttpStatusCode.Redirect, response.StatusCode);
            Assert.Contains("/Compte/Connexion", response.Headers.Location.OriginalString);
        }
    }
}
