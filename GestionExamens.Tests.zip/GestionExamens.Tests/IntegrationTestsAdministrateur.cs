using System.Net;
using System.Threading.Tasks;
using Xunit;
using Microsoft.AspNetCore.Mvc.Testing;

namespace GestionExamens.Tests
{
    public class IntegrationTestsAdministrateur : IClassFixture<WebApplicationFactory<GestionExamens.Program>>
    {
        private readonly WebApplicationFactory<GestionExamens.Program> _factory;

        public IntegrationTestsAdministrateur(WebApplicationFactory<GestionExamens.Program> factory)
        {
            _factory = factory;
        }

        [Fact]
        public async Task Get_GererUtilisateurs_UnauthorizedWithoutLogin()
        {
            var client = _factory.CreateClient();

            var response = await client.GetAsync("/Administrateur/GererUtilisateurs");

            Assert.Equal(HttpStatusCode.Redirect, response.StatusCode);
            Assert.Contains("/Compte/Connexion", response.Headers.Location.OriginalString);
        }
    }
}
