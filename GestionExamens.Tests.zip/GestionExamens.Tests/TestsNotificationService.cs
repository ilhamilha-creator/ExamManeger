using Xunit;
using GestionExamens.Services;
using System;

namespace GestionExamens.Tests
{
    public class TestsNotificationService
    {
        [Fact]
        public void EnvoyerEmail_ThrowsNotImplementedException()
        {
            var service = new NotificationService();
            Assert.Throws<NotImplementedException>(() => service.EnvoyerEmail());
        }

        [Fact]
        public void AfficherTableauDeBord_ThrowsNotImplementedException()
        {
            var service = new NotificationService();
            Assert.Throws<NotImplementedException>(() => service.AfficherTableauDeBord());
        }
    }
}
