using System.Threading.Tasks;
using Xunit;
using Microsoft.AspNetCore.Mvc.Testing;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Net.Http.Headers;

namespace GestionExamens.Tests
{
    public class IntegrationTestsBusinessScenarios : IClassFixture<WebApplicationFactory<GestionExamens.Program>>
    {
        private readonly WebApplicationFactory<GestionExamens.Program> _factory;

        public IntegrationTestsBusinessScenarios(WebApplicationFactory<GestionExamens.Program> factory)
        {
            _factory = factory;
        }

        [Fact]
        public async Task Etudiant_InscriptionExamen_Succeeds()
        {
            var client = _factory.CreateClient();

            // Simulate login as Etudiant (this would require a real login or mock)
            // For simplicity, assume authenticated client or mock authentication

            var response = await client.PostAsync("/Etudiant/InscriptionExamen", new StringContent("", Encoding.UTF8, "application/json"));

            Assert.True(response.StatusCode == HttpStatusCode.OK || response.StatusCode == HttpStatusCode.Redirect);
        }

        [Fact]
        public async Task Enseignant_SaisirNotes_Succeeds()
        {
            var client = _factory.CreateClient();

            var response = await client.PostAsync("/Enseignant/SaisirNotes", new StringContent("", Encoding.UTF8, "application/json"));

            Assert.True(response.StatusCode == HttpStatusCode.OK || response.StatusCode == HttpStatusCode.Redirect);
        }

        [Fact]
        public async Task Administrateur_GenererRapports_Succeeds()
        {
            var client = _factory.CreateClient();

            var response = await client.GetAsync("/Administrateur/GenererRapports");

            Assert.True(response.StatusCode == HttpStatusCode.OK || response.StatusCode == HttpStatusCode.Redirect);
        }
    }
}
