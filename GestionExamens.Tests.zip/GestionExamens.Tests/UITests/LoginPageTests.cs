using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Xunit;
using System;

namespace GestionExamens.Tests.UITests
{
    public class LoginPageTests : IDisposable
    {
        private IWebDriver _driver;

        public LoginPageTests()
        {
            var options = new ChromeOptions();
            options.AddArgument("--headless");
            _driver = new ChromeDriver(options);
        }

        [Fact]
        public void LoginPage_TitleIsCorrect()
        {
            _driver.Navigate().GoToUrl("https://localhost:5001/Compte/Connexion");
            Assert.Contains("Connexion", _driver.Title);
        }

        public void Dispose()
        {
            _driver.Quit();
            _driver.Dispose();
        }
    }
}
