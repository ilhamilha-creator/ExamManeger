using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Xunit;
using System;

namespace GestionExamens.Tests.UITests
{
    public class PagesTests : IDisposable
    {
        private IWebDriver _driver;

        public PagesTests()
        {
            var options = new ChromeOptions();
            options.AddArgument("--headless");
            _driver = new ChromeDriver(options);
        }

        [Fact]
        public void Page_Matiere_LoadsSuccessfully()
        {
            _driver.Navigate().GoToUrl("https://localhost:5001/Matiere");
            Assert.Contains("Matière", _driver.Title);
        }

        [Fact]
        public void Page_Examen_LoadsSuccessfully()
        {
            _driver.Navigate().GoToUrl("https://localhost:5001/Examen");
            Assert.Contains("Examen", _driver.Title);
        }

        [Fact]
        public void Page_Session_LoadsSuccessfully()
        {
            _driver.Navigate().GoToUrl("https://localhost:5001/Session");
            Assert.Contains("Session", _driver.Title);
        }

        public void Dispose()
        {
            _driver.Quit();
            _driver.Dispose();
        }
    }
}
