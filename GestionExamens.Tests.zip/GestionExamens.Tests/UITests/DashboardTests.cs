using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Xunit;
using System;

namespace GestionExamens.Tests.UITests
{
    public class DashboardTests : IDisposable
    {
        private IWebDriver _driver;

        public DashboardTests()
        {
            var options = new ChromeOptions();
            options.AddArgument("--headless");
            _driver = new ChromeDriver(options);
        }

        [Fact]
        public void DashboardPage_LoadsSuccessfully()
        {
            _driver.Navigate().GoToUrl("https://localhost:5001/");
            Assert.Contains("Tableau de bord", _driver.Title);
        }

        [Fact]
        public void Navigation_ToEtudiantPage_Works()
        {
            _driver.Navigate().GoToUrl("https://localhost:5001/");
            var link = _driver.FindElement(By.LinkText("Étudiant"));
            link.Click();
            Assert.Contains("/Etudiant", _driver.Url);
        }

        public void Dispose()
        {
            _driver.Quit();
            _driver.Dispose();
        }
    }
}
