using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Xunit;
using System;

namespace GestionExamens.Tests.UITests
{
    public class EndToEndTests : IDisposable
    {
        private IWebDriver _driver;

        public EndToEndTests()
        {
            var options = new ChromeOptions();
            options.AddArgument("--headless");
            _driver = new ChromeDriver(options);
        }

        [Fact]
        public void Etudiant_Flow_Login_Inscription_Notes_Rapport()
        {
            // Login
            _driver.Navigate().GoToUrl("https://localhost:5001/Compte/Connexion");
            _driver.FindElement(By.Id("Email")).SendKeys("etudiant@example.com");
            _driver.FindElement(By.Id("MotDePasse")).SendKeys("password");
            _driver.FindElement(By.Id("btnConnexion")).Click();

            // Navigate to Examens à venir
            _driver.FindElement(By.LinkText("Examens à venir")).Click();
            Assert.Contains("/Etudiant/ExamensAVenir", _driver.Url);

            // Simulate inscription à un examen (if button exists)
            var btnInscrire = _driver.FindElements(By.Id("btnInscrire"));
            if (btnInscrire.Count > 0)
            {
                btnInscrire[0].Click();
            }

            // Navigate to Notes
            _driver.FindElement(By.LinkText("Mes notes")).Click();
            Assert.Contains("/Etudiant/Notes", _driver.Url);

            // Navigate to Relevé de notes
            _driver.FindElement(By.LinkText("Relevé de notes")).Click();
            Assert.Contains("/Etudiant/TelechargerReleve", _driver.Url);

            // Logout
            _driver.FindElement(By.LinkText("Déconnexion")).Click();
            Assert.Contains("/Compte/Connexion", _driver.Url);
        }

        public void Dispose()
        {
            _driver.Quit();
            _driver.Dispose();
        }
    }
}
