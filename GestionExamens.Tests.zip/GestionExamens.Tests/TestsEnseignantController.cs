using Xunit;
using GestionExamens.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using GestionExamens.Data;
using Microsoft.EntityFrameworkCore;

namespace GestionExamens.Tests
{
    public class TestsEnseignantController
    {
        private ApplicationDbContext GetDbContext()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDbEnseignant")
                .Options;
            return new ApplicationDbContext(options);
        }

        private EnseignantController GetControllerWithUser(ApplicationDbContext context, string email)
        {
            var controller = new EnseignantController(context);

            var user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.Name, email),
                new Claim(ClaimTypes.Role, "Enseignant")
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user }
            };

            return controller;
        }

        [Fact]
        public void CreerExamen_ReturnsContentResult()
        {
            var context = GetDbContext();
            var controller = GetControllerWithUser(context, "enseignant@example.com");

            var result = controller.CreerExamen();

            Assert.IsType<ContentResult>(result);
        }

        [Fact]
        public void SaisirNotes_ReturnsContentResult()
        {
            var context = GetDbContext();
            var controller = GetControllerWithUser(context, "enseignant@example.com");

            var result = controller.SaisirNotes();

            Assert.IsType<ContentResult>(result);
        }

        [Fact]
        public void ListeEtudiants_ReturnsContentResult()
        {
            var context = GetDbContext();
            var controller = GetControllerWithUser(context, "enseignant@example.com");

            var result = controller.ListeEtudiants();

            Assert.IsType<ContentResult>(result);
        }

        [Fact]
        public void Statistiques_ReturnsContentResult()
        {
            var context = GetDbContext();
            var controller = GetControllerWithUser(context, "enseignant@example.com");

            var result = controller.Statistiques();

            Assert.IsType<ContentResult>(result);
        }
    }
}
