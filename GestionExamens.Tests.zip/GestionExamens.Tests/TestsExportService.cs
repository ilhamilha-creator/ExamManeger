using Xunit;
using GestionExamens.Services;
using System;

namespace GestionExamens.Tests
{
    public class TestsExportService
    {
        [Fact]
        public void ExporterEnPdf_WithMockData_ThrowsNotImplementedException()
        {
            var service = new ExportService();
            Assert.Throws<NotImplementedException>(() => service.ExporterEnPdf());
        }

        [Fact]
        public void ExporterEnExcel_WithMockData_ThrowsNotImplementedException()
        {
            var service = new ExportService();
            Assert.Throws<NotImplementedException>(() => service.ExporterEnExcel());
        }
    }
}
