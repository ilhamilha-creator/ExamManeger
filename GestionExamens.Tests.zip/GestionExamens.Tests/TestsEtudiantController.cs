using Xunit;
using GestionExamens.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using GestionExamens.Data;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System.Collections.Generic;
using GestionExamens.Models;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;

namespace GestionExamens.Tests
{
    public class TestsEtudiantController
    {
        private ApplicationDbContext GetDbContext()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDb")
                .Options;
            return new ApplicationDbContext(options);
        }

        private EtudiantController GetControllerWithUser(ApplicationDbContext context, string email)
        {
            var controller = new EtudiantController(context);

            var user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.Name, email),
                new Claim(ClaimTypes.Role, "Etudiant")
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user }
            };

            return controller;
        }

        [Fact]
        public async Task ExamensAVenir_ReturnsViewResult()
        {
            var context = GetDbContext();
            var controller = GetControllerWithUser(context, "etudiant@example.com");

            var result = await controller.ExamensAVenir();

            Assert.IsType<ViewResult>(result);
        }

        [Fact]
        public async Task Notes_ReturnsViewResult()
        {
            var context = GetDbContext();
            context.Etudiants.Add(new Etudiant { Id = 1, Email = "etudiant@example.com" });
            context.SaveChanges();

            var controller = GetControllerWithUser(context, "etudiant@example.com");

            var result = await controller.Notes();

            Assert.IsType<ViewResult>(result);
        }

        [Fact]
        public void TelechargerReleve_ReturnsContentResult()
        {
            var context = GetDbContext();
            var controller = GetControllerWithUser(context, "etudiant@example.com");

            var result = controller.TelechargerReleve();

            Assert.IsType<ContentResult>(result);
        }

        [Fact]
        public void InscriptionExamen_ReturnsContentResult()
        {
            var context = GetDbContext();
            var controller = GetControllerWithUser(context, "etudiant@example.com");

            var result = controller.InscriptionExamen();

            Assert.IsType<ContentResult>(result);
        }
    }
}
