using Xunit;
using GestionExamens.Services;
using System;

namespace GestionExamens.Tests
{
    public class TestsServices
    {
        [Fact]
        public void ExportService_ExporterEnPdf_ThrowsNotImplementedException()
        {
            var service = new ExportService();
            Assert.Throws<NotImplementedException>(() => service.ExporterEnPdf());
        }

        [Fact]
        public void ExportService_ExporterEnExcel_ThrowsNotImplementedException()
        {
            var service = new ExportService();
            Assert.Throws<NotImplementedException>(() => service.ExporterEnExcel());
        }

        [Fact]
        public void NotificationService_EnvoyerEmail_ThrowsNotImplementedException()
        {
            var service = new NotificationService();
            Assert.Throws<NotImplementedException>(() => service.EnvoyerEmail());
        }

        [Fact]
        public void NotificationService_AfficherTableauDeBord_ThrowsNotImplementedException()
        {
            var service = new NotificationService();
            Assert.Throws<NotImplementedException>(() => service.AfficherTableauDeBord());
        }
    }
}
