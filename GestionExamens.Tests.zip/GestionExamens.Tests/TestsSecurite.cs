using Xunit;
using GestionExamens.Controllers;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace GestionExamens.Tests
{
    public class TestsSecurite
    {
        private TController GetControllerWithRole<TController>(string role) where TController : Controller, new()
        {
            var controller = new TController();

            var user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.Role, role)
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user }
            };

            return controller;
        }

        [Fact]
        public void EtudiantController_AccessDenied_ForEnseignantRole()
        {
            var controller = GetControllerWithRole<GestionExamens.Controllers.EtudiantController>("Enseignant");

            var result = controller.ExamensAVenir();

            Assert.IsType<ForbidResult>(result);
        }

        [Fact]
        public void EnseignantController_AccessDenied_ForEtudiantRole()
        {
            var controller = GetControllerWithRole<GestionExamens.Controllers.EnseignantController>("Etudiant");

            var result = controller.CreerExamen();

            Assert.IsType<ForbidResult>(result);
        }

        [Fact]
        public void AdministrateurController_AccessDenied_ForEtudiantRole()
        {
            var controller = GetControllerWithRole<GestionExamens.Controllers.AdministrateurController>("Etudiant");

            var result = controller.GererUtilisateurs();

            Assert.IsType<ForbidResult>(result);
        }
    }
}
