using Xunit;
using GestionExamens.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace GestionExamens.Tests
{
    public class TestsAdministrateurController
    {
        private AdministrateurController GetControllerWithUser()
        {
            var controller = new AdministrateurController();

            var user = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.Name, "admin@example.com"),
                new Claim(ClaimTypes.Role, "Administrateur")
            }, "mock"));

            controller.ControllerContext = new ControllerContext()
            {
                HttpContext = new DefaultHttpContext() { User = user }
            };

            return controller;
        }

        [Fact]
        public void GererUtilisateurs_ReturnsContentResult()
        {
            var controller = GetControllerWithUser();

            var result = controller.GererUtilisateurs();

            Assert.IsType<ContentResult>(result);
        }

        [Fact]
        public void GererMatieres_ReturnsContentResult()
        {
            var controller = GetControllerWithUser();

            var result = controller.GererMatieres();

            Assert.IsType<ContentResult>(result);
        }

        [Fact]
        public void GererSessions_ReturnsContentResult()
        {
            var controller = GetControllerWithUser();

            var result = controller.GererSessions();

            Assert.IsType<ContentResult>(result);
        }

        [Fact]
        public void VerifierNotes_ReturnsContentResult()
        {
            var controller = GetControllerWithUser();

            var result = controller.VerifierNotes();

            Assert.IsType<ContentResult>(result);
        }

        [Fact]
        public void PublierResultats_ReturnsContentResult()
        {
            var controller = GetControllerWithUser();

            var result = controller.PublierResultats();

            Assert.IsType<ContentResult>(result);
        }

        [Fact]
        public void GenererRapports_ReturnsContentResult()
        {
            var controller = GetControllerWithUser();

            var result = controller.GenererRapports();

            Assert.IsType<ContentResult>(result);
        }
    }
}
